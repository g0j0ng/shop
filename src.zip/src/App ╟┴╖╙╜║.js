//  프롭스 

import logo from './logo.svg';
import './App.css';
import {Header,Section,Footer} from './Components';
// import Header from './Components';
// import Section from './Section';
// import Footer from './Footer';

function App() {
  return (
    <div className="App">
      
      <Header name1={console.log(1)} name2={function(){
        console.log('안녕하세요');
      }}/>
      <Section setContent={['일','이','삼','사']} />
      <Footer setClass={
        
          {
          name:'홍길동',
          age:20,
          address:'서울',
          consolePrint:function(){
            console.log('하이')
            },
          }
        
          }/>
    </div>
  );
}



export default App;
