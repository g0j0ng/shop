// 라우터---------------------------

import './App.css';
import {useState} from 'react';
import srcData from './srcData.js';
import { Button,Card } from 'react-bootstrap';
import {Switch,Route,Link} from "react-router-dom";

// const root = ReactDOM.createRoot(document.getElementById('root'));

function SecContainer(props){
  return (
    
    <div className="container">
      {
        props.wear.map((item,idx,arr)=>{
          return (
            <div key={item.id} className="card">
              <h2>{item.title}</h2>
              <p>{item.content}</p>
              <p>{item.price}</p>
            </div>
          );
        })
      }
    </div>
  );
}

function Footer(props) {
  return (
    <footer onClick={props.onClick}>
      푸터
    </footer>
  );
}

function Input(props) {
  return (
    <input type="text" onChange={(event)=>{props.onChange(event)}}/>

  );

}

function App() {
  let [wear,wearChange] = useState(srcData);

  
  return (
    <div className="App">
      <Link to="/">홈으로</Link>
      <Link to="/sec1">sec1</Link>
      <Link to="/sec2">sec2</Link>

    <Switch>
      <Route path="/sec1">
        <section>
          <Input onChange={(t)=>{console.log(t.target.value)}}/>
          <button>클릭</button>
          <SecContainer wear={wear} wearChange={wearChange}/>
        </section>
      </Route>
        
      <Route path="/sec2">
        <section>
          <Card style={{ width: '18rem' }}>
            <Card.Img variant="top" src="holder.js/100px180" />
            <Card.Body>
              <Card.Title>Card Title</Card.Title>
              <Card.Text>
                Some quick example text to build on the card title and make up the bulk of
                the card's content.
              </Card.Text>
              <Button variant="primary">Go somewhere</Button>
            </Card.Body>
          </Card>
        </section>
      </Route>

      <Route exact path="/">
        <header>
          <h1>쇼핑몰</h1>
        </header>
      </Route>
    </Switch>

      <Footer onClick={()=>{
        console.log('푸터')
      }}/>
      
    </div>

  );
}



export default App;
