// 스테이트


import logo from './logo.svg';

import './App.css';

import {useState} from 'react';

function App() {

  // let [flag,flagChange] = useState(false);

  // ['바지','변경함수'] 이런식으로 변경한거임
  let [uniform,uniformChange] = useState(['바지','브라우스','머리띠','조끼','양말','구두','운동화']); 
  
  function changeUniform(){
    let copyUniform = [...uniform];
    copyUniform[0]='치마';
    uniformChange(copyUniform);
  }

  function conPrint(){
    console.log(1);
  }
  return (
    <div className="App">    
      <h1>{`여성용 정장 ${uniform[0]}와 ${uniform[1]}`}</h1>
      <button onClick={()=> {changeUniform(); conPrint();} }>옷이름변경</button>
      {/* <button onClick={ ()=>{conPrint}}>옷이름변경</button> */}
    </div>
  );
}



export default App;
